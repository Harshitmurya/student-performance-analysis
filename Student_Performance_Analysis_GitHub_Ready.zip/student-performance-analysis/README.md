# Student Performance Analysis and Score Prediction

A beginner-friendly Data Science project that demonstrates data loading, validation,
exploratory data analysis, visualization, Linear Regression, and model evaluation.

## Project files

- `student_performance.py` — main Python source code
- `student_performance.csv` — 100 synthetic sample records
- `requirements.txt` — Python dependencies
- `outputs/` — generated charts (created when the script runs)

## Requirements

- Python 3.9 or newer
- pip

## Installation

```bash
pip install -r requirements.txt
```

## Run the project

```bash
python student_performance.py
```

The script prints a dataset preview, descriptive statistics, missing-value counts,
test-set evaluation metrics, model coefficients, and one illustrative prediction.
It also creates three charts in the `outputs` folder.

## Dataset columns

| Column | Description |
|---|---|
| `student_id` | Synthetic record identifier |
| `study_hours_per_day` | Illustrative study hours per day |
| `attendance_percent` | Illustrative attendance percentage |
| `previous_score` | Illustrative previous score |
| `assignments_completed` | Illustrative completed assignments |
| `final_score` | Synthetic target score from 0 to 100 |

## Model

The project uses a baseline `LinearRegression` model from scikit-learn.
The data is divided into 80% training and 20% testing subsets.

Evaluation metrics:
- MAE: Mean Absolute Error
- RMSE: Root Mean Squared Error
- R²: Coefficient of determination

## Important note

The bundled dataset is synthetic and generated for demonstration. It does not contain
real student records. The model and its metrics must not be used for real academic
decisions, ranking, or assessment. Correlation does not prove causation.

## GitHub upload

Create a new repository on GitHub, then upload these files and folders. Include the
README and requirements file so others can understand and run the project.
